<<<<<<< HEAD
# Print welcome message with gaming-style installation sequence
ui_print "╔══════════════════════════════════════╗"
ui_print "║     60 FPS ULOCKER INSTALLATION    ║"
ui_print "╚══════════════════════════════════════╝"
sleep 1

ui_print ""
ui_print "[*] Initializing FPS optimization module..."
sleep 0.7

ui_print "[*] Analyzing device GPU configuration..."
sleep 1

ui_print "[+] Applying performance tweaks:"
sleep 0.5
ui_print "    ▸ Unlocking frame rate limits"
sleep 0.3
ui_print "    ▸ Optimizing GPU parameters"
sleep 0.3
ui_print "    ▸ Configuring render settings"
sleep 0.8

ui_print "[*] Finalizing optimization setup..."
sleep 0.5

ui_print ""
ui_print "✓ Installation Complete!"
ui_print "→ Developed by yadavnikhil03"
ui_print "→ For Gamers, By a Gamer 🎮"
ui_print ""
=======
# Print welcome message
ui_print "1. Activating Maximum Graphics Settings for BGMI/PUBG!"
ui_print "2. Boosting GPU Performance with Optimized Tweaks"
ui_print "   by yadavnikhil03"
>>>>>>> 5bbc55447f3f322bc59bd3c98deccd89a4adbc5f
